<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>LogIn Form</title>
  <link rel="stylesheet" href="css/login.css">
</head>
    <body>
        <section class="container">
            <div class="login">
                <h1>Авторизация</h1>
                <form method="post" action="login.php">
                    <label>E-mail</label>
                    <input type="text" name="email" value="" placeholder="E-mail">
                    <label>Пароль</label>
                    <input type="password" name="password" value="" placeholder="Пароль">
                    <p class="remember_me">
                        <label>
                            <input type="checkbox" name="remember_me" id="remember_me">
                            Запомнить меня на этом компьютере
                        </label>
                    </p><br>
                    <p class="submit"><input type="submit" name="commit" value="Войти" id="loginButton"></p>
                </form>
                
            </div>
        </section>

        <!-- <script>
            function redirectToIndex() {
                window.location.href = 'index.html';
            }

            // Находим кнопку "Войти"
            const loginButton = document.getElementById('loginButton');

            // Добавляем обработчик события "click"
            loginButton.addEventListener('click', function(event) {
                // Предотвращаем отправку формы
                event.preventDefault();

                // Вызываем функцию для перенаправления на страницу index.html
                redirectToIndex();
            });
        </script> -->
    </body>
</html>

<?php
// Подключение к базе данных (замените 'hostname', 'username', 'password' и 'database' на свои значения)
$mysqli = new mysqli('localhost', 'root', '', 'desert');

// Проверка соединения
if ($mysqli->connect_error) {
    die('Ошибка подключения (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}

// Проверка наличия данных в POST запросе
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Проверка наличия необходимых полей в POST запросе
    if (isset($_POST['email'], $_POST['password'])) {
        // Получение данных из POST запроса
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Подготовка SQL запроса для проверки наличия пользователя в базе данных
        $query = "SELECT * FROM login WHERE email = ?";

        // Подготовка и выполнение запроса
        if ($stmt = $mysqli->prepare($query)) {
            // Привязка параметров к запросу
            $stmt->bind_param("s", $email);

            // Выполнение запроса
            if ($stmt->execute()) {
                // Получение результата запроса
                $result = $stmt->get_result();

                // Проверка наличия пользователя в базе данных
                if ($result->num_rows == 1) {
                    $row = $result->fetch_assoc();
                    $firstName = $row['Name'];
                    $lastName = $row['Lastname'];
                    
                    // Перенаправление на index1.php с передачей имени и фамилии в виде параметров URL
                    header("Location: index1.php?Name=$firstName&Lastname=$lastName");
                    
                    exit();
            } else {
                echo "Ошибка при выполнении запроса: " . $stmt->error;
            }
            }
            // Закрытие запроса
            $stmt->close();
        } else {
            echo "Ошибка при подготовке запроса: " . $mysqli->error;
        }
    } else {
        echo "Необходимые поля не были переданы";
    }
}

// Закрытие соединения с базой данных
$mysqli->close();
?>
