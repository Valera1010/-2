<!DOCTYPE html>
<html lang="en"><!-- Basic -->
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
     <!-- Site Metas -->
    <title>Desert</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">    
	<!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/buy.css">    
    <link rel="stylesheet" href="css/buttonbuyy.css">  
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    

</head>

<body>

<div id="container">
  <h1>&bull; Заказ товара &bull;</h1>
  <div class="underline">
  </div>
  <form action="#" method="post" id="contact_form">
    <div class="name">
      <label for="name"></label>
      <input type="text" placeholder="Введите имя" name="name" id="name_input" required>
    </div>
    <div class="email">
      <label for="email"></label>
      <input type="email" placeholder="Введите email" name="email" id="email_input" required>
    </div>
    <div class="telephone">
      <label for="name"></label>
      <input type="text" placeholder="Введите номер телефона" name="telephone" id="telephone_input" required>
    </div>
    <div class="address">
      <label for="name"></label>
      <input type="text" placeholder="Адрес" name="address" id="address_input" required>
    </div>
    <div class="subject">
      <label for="subject"></label>
      <select placeholder="Subject line" name="subject" id="subject_input" required>
        <option disabled hidden selected>Выберите товар</option>
        <option>Медовик</option>
        <option>Красный бархат</option>
        <option>Шоколадное печенье</option>
        <option>Эклер</option>
        <option>Макароны</option>
        <option>Овсяное печенье</option>
        <option>Корзинка</option>
      </select>
    </div>
    <div class="message">
      <label for="message"></label>
      <textarea name="message" placeholder="Желаемое количество (шт)" id="message_input" cols="30" rows="5" required></textarea>
    </div>
    <div class="submit">
      <input type="submit" value="ЗАКАЗАТЬ" id="form_button" />
    </div>
  </form><!-- // End form -->
</div><!-- // End #container -->


<a href="index1.php" class="gradient-button">Главная</a>

<button id="export_button">Экспорт чека в Excel</button>
<!-- Подключаем библиотеку SheetJS для работы с Excel -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.16.9/xlsx.full.min.js"></script>
<!-- Скрипт для экспорта данных в Excel -->
<script>
    document.getElementById('form_button').addEventListener('click', function() {
        // Создаем новую книгу Excel
        var wb = XLSX.utils.book_new();
        var ws_data = [];
        
        // Получаем данные из формы
        var name = document.getElementById('name_input').value;
        var email = document.getElementById('email_input').value;
        var telephone = document.getElementById('telephone_input').value;
        var address = document.getElementById('address_input').value;
        var subject = document.getElementById('subject_input').value;
        var message = document.getElementById('message_input').value;

        // Получаем текущую дату
        var currentDate = new Date();
        var dateString = currentDate.toLocaleDateString();

        // Получаем текущее время
        var currentTime = new Date();
        var timeString = currentTime.toLocaleTimeString();

        // Записываем данные в массив
        ws_data.push(["Наименование товара", "Имя покупателя", "Адрес", "Номер телефона", "Email", "Количество", "Дата заказа", "Время заказа"]);
        ws_data.push([subject, name, address, telephone, email, message, dateString, timeString]);

        // Создаем новый лист в книге
        var ws = XLSX.utils.aoa_to_sheet(ws_data);
        XLSX.utils.book_append_sheet(wb, ws, "Заказ");

        // Сохраняем файл Excel
        XLSX.writeFile(wb, "check.xlsx");
    });
</script>
</body>
</html>

<?php
// Подключение к базе данных (замените 'hostname', 'username', 'password' и 'database' на свои значения)
$mysqli = new mysqli('localhost', 'root', '', 'desert');

// Проверка соединения
if ($mysqli->connect_error) {
    die('Ошибка подключения (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}

// Проверка наличия данных в POST запросе
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получение данных из формы
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['telephone'];
    $address = $_POST['address'];
    $title = $_POST['subject'];
    $count = $_POST['message'];

    // Подготовка SQL запроса для вставки данных в таблицу buy
    $query = "INSERT INTO buy (name, email, phone, address, title, count) VALUES (?, ?, ?, ?, ?, ?)";

    // Подготовка и выполнение запроса
    if ($stmt = $mysqli->prepare($query)) {
        // Привязка параметров к запросу
        $stmt->bind_param("sssssi", $name, $email, $phone, $address, $title, $count);

        // Выполнение запроса
        if ($stmt->execute()) {
            echo "Заказ успешно добавлен в базу данных.";
        } else {
            echo "Ошибка при выполнении запроса: " . $stmt->error;
        }

        // Закрытие запроса
        $stmt->close();
    } else {
        echo "Ошибка при подготовке запроса: " . $mysqli->error;
    }
}

// Закрытие соединения с базой данных
$mysqli->close();
?>

