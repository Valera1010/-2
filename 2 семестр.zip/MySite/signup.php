<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>SignUp Form</title>
  <link rel="stylesheet" href="css/signup.css">
</head>
<body>
        <section class="container">
            <div class="login">
                <h1>Регистрация</h1>
                <form method="post" action="signup.php">
                    <label>E-mail</label>
                    <input type="text" value="" placeholder="E-mail" name="email">
                    <label>Фамилия</label>
                    <input type="text" value="" placeholder="Фамилия" name="lastname">
                    <label>Имя</label>
                    <input type="text" value="" placeholder="Имя" name="name">
                    <label>Пароль</label>
                    <input type="password" value="" placeholder="Пароль" name="password">
                    <label>Повторите пароля</label>
                    <input type="password" value="" placeholder="Повтор пароля" name="confirmPassword">
                    <p class="remember_me">
                        <label>
                            <input type="checkbox" name="remember_me" id="remember_me">
                            Я даю подтверждение на обработку персональных данных
                        </label>
                    </p>
                    <p class="submit"><input type="submit" name="commit" value="Зарегистрироваться"></p>
                    <p class="submit"><input type="submit" name="commit" value="Войти" id="loginButton"></p>
                </form>
            </div>
        </section>
    </body>
</html>
<script>
            function redirectToIndex() {
                window.location.href = 'login.php';
            }

            // Находим кнопку "Войти"
            const loginButton = document.getElementById('loginButton');

            // Добавляем обработчик события "click"
            loginButton.addEventListener('click', function(event) {
                // Предотвращаем отправку формы
                event.preventDefault();

                // Вызываем функцию для перенаправления на страницу index.html
                redirectToIndex();
            });
        </script>
<?php
// Подключение к базе данных (замените 'hostname', 'username', 'password' и 'database' на свои значения)
$mysqli = new mysqli('localhost', 'root', '', 'desert');

// Проверка соединения
if ($mysqli->connect_error) {
    die('Ошибка подключения (' . $mysqli->connect_errno . ') ' . $mysqli->connect_error);
}

// Проверка наличия данных в POST запросе
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Проверка наличия необходимых полей в POST запросе
    if (isset($_POST['email'], $_POST['lastname'], $_POST['name'], $_POST['password'])) {
        // Получение данных из POST запроса
        $email = $_POST['email'];
        $lastname = $_POST['lastname'];
        $name = $_POST['name'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirmPassword'];

        // Проверка соответствия пароля и его подтверждения
        if ($password !== $confirmPassword) {
            echo "Пароли не совпадают";
            exit;
        }

        // Хэширование пароля (лучше использовать более безопасные методы хэширования)
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Подготовка SQL запроса для вставки данных в базу данных
        $query = "INSERT INTO login (Email, Lastname, Name, Password) VALUES (?, ?, ?, ?)";

        // Подготовка и выполнение запроса
        if ($stmt = $mysqli->prepare($query)) {
            // Привязка параметров к запросу
            $stmt->bind_param("ssss", $email, $lastname, $name, $hashedPassword);

            // Выполнение запроса
            if ($stmt->execute()) {
                echo '<div style="background-color: green; color: white; padding: 10px; font-size: 20px; text-align:center;">Регистрация прошла успешно</div>';
                //header("Location: login.php");
                    //exit();
            } else {
                echo "Ошибка при выполнении запроса: " . $stmt->error;
            }

            // Закрытие запроса
            $stmt->close();
        } else {
            echo "Ошибка при подготовке запроса: " . $mysqli->error;
        }
    } else {
        echo "Необходимые поля не были переданы";
    }
}

// Закрытие соединения с базой данных
$mysqli->close();
?>

