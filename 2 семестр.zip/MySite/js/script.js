document.getElementById('showFormButton').addEventListener('click', function() {
    document.getElementById('registrationForm').classList.remove('hidden');
  });
  