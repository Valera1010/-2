
-- --------------------------------------------------------

--
-- Структура таблицы `question`
--

CREATE TABLE `question` (
  `ID` int NOT NULL,
  `Name` text NOT NULL,
  `Email` text NOT NULL,
  `Question` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `question`
--

INSERT INTO `question` (`ID`, `Name`, `Email`, `Question`) VALUES
(1, 'Станислав', 'stasopop@gmail.com', 'Можно 6?'),
(4, 'Валерий', 'teteryk04@gmail.com', 'Скидку сделаете?'),
(5, 'Валерий', 'volk@gmail.com', 'Обменяю хонду взамен на какой-нибудь тортик'),
(6, 'Валерий', 'volk@gmail.com', 'Обменяю хонду взамен на какой-нибудь тортик');
