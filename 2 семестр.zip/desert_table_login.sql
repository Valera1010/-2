
-- --------------------------------------------------------

--
-- Структура таблицы `login`
--

CREATE TABLE `login` (
  `ID` int NOT NULL,
  `Email` text NOT NULL,
  `Lastname` text NOT NULL,
  `Name` text NOT NULL,
  `Password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `login`
--

INSERT INTO `login` (`ID`, `Email`, `Lastname`, `Name`, `Password`) VALUES
(1, 'stasopop@gmail.com', 'Шестакович', 'Станислав', '$2y$10$n67Yt6O6nB4c5vcr7r3Tgu1Af6hDHcMBEmxVT1IWhI8bShP/9rmqm'),
(2, 'teteryk04@gmail.com', 'Янченя', 'Валерий', '$2y$10$QX2nEkpUjrvCoRM72bfHA.QB4BPsOp4zhZAfx4tl5c6o47WApuQTG'),
(13, 'volk@gmail.com', 'Волк', 'Валерий', '$2y$10$.w28Df22Bs3F1T9z5jVU8O9atwUBsNWxcSdPXmkXCoj52mRDki1hK'),
(17, 'furman@gmail.com', 'Фурман', 'Никита', '$2y$10$FrcqD4yk8CKBzkBsdkOQQOMAzOlM4bo0Nl2O1c4BJ8XdS3RTOvXz6');
