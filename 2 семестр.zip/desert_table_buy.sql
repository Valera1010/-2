
-- --------------------------------------------------------

--
-- Структура таблицы `buy`
--

CREATE TABLE `buy` (
  `idBuy` int NOT NULL,
  `name` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `count` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `buy`
--

INSERT INTO `buy` (`idBuy`, `name`, `email`, `phone`, `address`, `title`, `count`) VALUES
(1, 'Станислав', 'stasopop@gmail.com', '375445451077', 'Гая 11', 'Медовик', '5'),
(5, 'Станислав', 'stasopop@gmail.com', '375445451077', 'Гая 11', 'Эклер', '5'),
(6, 'Станислав', 'stasopop@gmail.com', '375445451077', 'Гая 11', 'Эклер', '5'),
(7, 'Валерий', 'teteryk04@gmail.com', '375445451077', 'Ожешко 52', 'Корзинка', '10'),
(8, 'Валерий', 'teteryk04@gmail.com', '375445451077', 'Ожешко 52', 'Корзинка', '10'),
(9, 'Станислав', 'stasopop@gmail.com', '375445451077', 'Гая 11', 'Овсяное печенье', '5'),
(10, 'Станислав', 'stasopop@gmail.com', '375445451077', 'Гая 11', 'Овсяное печенье', '5'),
(11, 'Станислав', 'stasopop@gmail.com', '375445451077', 'Гая 11', 'Овсяное печенье', '5');
