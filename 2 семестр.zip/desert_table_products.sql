
-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `idProduct` int NOT NULL,
  `title` varchar(30) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(300) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`idProduct`, `title`, `image`, `description`, `price`) VALUES
(2, 'Медовик', 'img-02.jpg', 'Очень вкусный Медовик', 22),
(3, 'Красный бархат', 'img-03.jpg', 'Сочный', 30),
(4, 'Эклер', 'img-04.jpg', 'Французское пирожное', 2),
(5, 'Корзинка', 'img-05.jpg', 'Вкусное пирожное', 1),
(6, 'Макароны', 'img-06.jpg', 'Французский печенье', 7),
(7, 'Шоколадное печенье', 'img-07.jpg', 'Десерт для всей семьи', 12),
(8, 'Овсяное печенье', 'img-08.jpg', 'Печенье детства', 6);
