<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Сохранение имени и фамилии</title>
</head>
<body>
    <h1>Введите свои данные</h1>
    <form action="process.php" method="post">
        <label for="name">Имя:</label>
        <input type="text" id="name" name="name" required>
        <br>
        <label for="gender">Пол:</label>
        <select id="gender" name="gender" required>
            <option value="">Выберите...</option>
            <option value="male">Мужчина</option>
            <option value="female">Женщина</option>
        </select>
        <br>
        <label for="surname">Фамилия:</label>
        <input type="text" id="surname" name="surname" required>
        <br>
        <br>
        <input type="submit" value="Отправить">
    </form>
</body>
</html>
